# Multi-arch Node-RED container

This is a sample project to build multi-arch Node-RED containers with a view to creating learning assets to help a developer create production ready Node-RED apps.

To build the content it is assumed you are running on an Intel system with docker installed and running.

The following steps are needed to enable docker to run multi-arch containers (Note: this is not necessary if running Docker Desktop for Mac, as that is already enabled for multiarch).  For the Docker files in the project the **x86_64_qemu-{$arch}-static** files need to be in the project folder.

1. docker run --rm --privileged multiarch/qemu-user-static:register
2. Run the following (or equiv if not on unix based system):
  
    ```bash
    for target_arch in arm aarch64 ppc64le s390x ; do
      wget -N https://github.com/multiarch/qemu-user-static/releases/download/v2.9.1-1/x86_64_qemu-${target_arch}-static.tar.gz
      tar -xvf x86_64_qemu-${target_arch}-static.tar.gz
    done
    ```
